export default class Usuario{
    uid: String;
    email: string;
    displayName: string;
    photourl: string;
}