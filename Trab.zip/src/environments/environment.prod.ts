export const environment = {
  production: true,
  firebaseConfig : {
  apiKey: "AIzaSyBK0GcHdLap7gSEDnXYsrSbOkn-Z1i_urU",
  authDomain: "trabalho-ee47f.firebaseapp.com",
  projectId: "trabalho-ee47f",
  storageBucket: "trabalho-ee47f.appspot.com",
  messagingSenderId: "117243573510",
  appId: "1:117243573510:web:10c39acbe16cc201b21a87"
}
}
  
